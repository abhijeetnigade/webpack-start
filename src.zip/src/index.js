import './scss/main.scss';

console.log("Hello World !!");
var bdy=document.getElementsByTagName('body')[0];
//bdy.innerHTML='<button onclick="window.testScript();">Click ME</button>';
console.log(xml);